print('service t1\ttest')
