# -*- coding: utf-8 -*-
# @Author: leonliang
# @Date:   2018-07-1 15:16:42
# @Last Modified by:   leonliang
# @Last Modified time: 2018-07-8 10:37:51
import time
import re
import json
import FWWebAPI.Business.Config as GlobalVar 
import FWWebAPI.Business.toolkits as toolkits
import FWWebAPI.Business.ParserDataStructure as PDStructure
import FWWebAPI.Business.ParserDictionary as PDDict


class ParserDataSrv(object):
    """用于解析传输数据类型"""


if __name__ == '__main__':
    pass
